# Deep Learning Image Classification using PyTorch

## Install Libraries
pip install -r requirements.txt

## Run Training
python train.py

## Run Evaluation
python evaluate.py

## Results
Test Accuracy: 80.41%
